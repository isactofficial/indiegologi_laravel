

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4" style="min-height: 100vh;">

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-white rounded-4 shadow-sm p-4" style="border-left: 8px solid #f4b704;">
                <div class="d-flex align-items-center">
                    <div class="d-flex justify-content-center align-items-center rounded-circle me-4"
                         style="width: 70px; height: 70px; background-color: rgba(244, 183, 4, 0.1);">
                        <i class="fas fa-tags fs-2" style="color: #f4b704;"></i>
                    </div>
                    <div>
                        <h2 class="fs-3 fw-bold mb-1" style="color: #f4b704;">Manajemen Referral</h2>
                        <p class="text-muted mb-0">Kelola kode referral untuk promosi.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-12 d-flex justify-content-end">
            <a href="<?php echo e(route('admin.referral-codes.create')); ?>" class="btn btn-sporty-primary d-flex align-items-center px-4 py-2">
                <i class="fas fa-plus me-2"></i>
                <span class="fw-semibold">Tambah Kode Referral</span>
            </a>
        </div>
    </div>

    
    <div class="card border-0 rounded-4 shadow-sm">
        <div class="card-body p-4">
            <?php if(session('success')): ?>
                <div class="alert alert-success rounded-3 alert-custom-success mb-4"><i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th class="py-3">Kode</th>
                            <th class="py-3">Diskon</th>
                            <th class="py-3">Maks Penggunaan</th>
                            <th class="py-3">Digunakan</th>
                            <th class="py-3">Status</th>
                            <th class="py-3">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $referralCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr style="border-bottom: 1px solid #f0f0f0;">
                                <td class="py-3 fw-semibold text-break"><?php echo e($code->code); ?></td>
                                <td class="py-3"><?php echo e($code->discount_percentage); ?>%</td>
                                <td class="py-3"><?php echo e($code->max_uses ?? 'Tidak Terbatas'); ?></td>
                                <td class="py-3"><?php echo e($code->current_uses); ?></td>
                                <td class="py-3">
                                    <?php
                                        $status = 'Aktif';
                                        $statusClass = 'badge-status-published'; // Menggunakan class badge artikel untuk konsistensi
                                        $now = now();
                                        if ($code->valid_until && $now->isAfter($code->valid_until)) {
                                            $status = 'Kedaluwarsa';
                                            $statusClass = 'badge-status-draft';
                                        } elseif ($code->max_uses && $code->current_uses >= $code->max_uses) {
                                            $status = 'Habis';
                                            $statusClass = 'badge-status-draft';
                                        }
                                    ?>
                                    <span class="badge <?php echo e($statusClass); ?>"><?php echo e($status); ?></span>
                                </td>
                                <td class="py-3">
                                    <div class="d-flex gap-2">
                                        <a href="<?php echo e(route('admin.referral-codes.edit', $code->id)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3" style="border-color: #f4b704; color: #f4b704;" title="Edit Kode">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.referral-codes.destroy', $code->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" onclick="confirmDelete(event, this.parentElement)" class="btn btn-sm btn-outline-danger rounded-pill px-3" style="border-color: #cb2786; color: #cb2786;" title="Hapus Kode">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    <i class="fas fa-box-open me-2"></i>Tidak ada kode referral yang ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($referralCodes->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(event, form) {
        event.preventDefault();
        Swal.fire({
            title: "Yakin ingin menghapus kode ini?",
            text: "Anda tidak akan bisa mengembalikannya!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#cb2786",
            cancelButtonColor: "#808080",
            confirmButtonText: "Ya, Hapus Sekarang!",
            cancelButtonText: "Batalkan",
            customClass: {
                popup: 'rounded-4',
                confirmButton: 'rounded-pill px-4',
                cancelButton: 'rounded-pill px-4'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Internshipractice\indiegologi_laravel\resources\views/referral-codes/index.blade.php ENDPATH**/ ?>