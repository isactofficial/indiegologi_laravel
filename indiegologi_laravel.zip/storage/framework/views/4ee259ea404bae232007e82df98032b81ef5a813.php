

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4" style="min-height: 100vh;">

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-white rounded-4 shadow-sm p-4" style="border-left: 8px solid #cb2786;">
                <div class="d-flex align-items-center">
                    <div class="d-flex justify-content-center align-items-center rounded-circle me-4"
                         style="width: 70px; height: 70px; background-color: rgba(203, 39, 134, 0.1);">
                        <i class="fas fa-palette fs-2" style="color: #cb2786;"></i>
                    </div>
                    <div>
                        <h2 class="fs-3 fw-bold mb-1" style="color: #cb2786;">Manajemen Sketsa</h2>
                        <p class="text-muted mb-0">Kelola koleksi sketsa Anda di sini.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-12 d-flex justify-content-end">
            <a href="<?php echo e(route('admin.sketches.create')); ?>" class="btn btn-sporty-primary d-flex align-items-center px-4 py-2">
                <i class="fas fa-plus me-2"></i>
                <span class="fw-semibold">Tambah Sketsa Baru</span>
            </a>
        </div>
    </div>

    
    <div class="card border-0 rounded-4 shadow-sm">
        <div class="card-body p-4">
            <?php if(session('success')): ?>
                <div class="alert alert-success rounded-3 alert-custom-success mb-4"><i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th class="py-3">Thumbnail</th>
                            <th class="py-3">Judul Sketsa</th>
                            <th class="py-3">Penulis</th>
                            <th class="py-3">Status</th>
                            <th class="py-3">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sketches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sketch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr style="border-bottom: 1px solid #f0f0f0;">
                                <td class="py-3">
                                    
                                    <?php if($sketch->thumbnail): ?>
                                        <img src="<?php echo e(asset('storage/' . $sketch->thumbnail)); ?>" alt="<?php echo e($sketch->title); ?>" class="rounded-3 object-fit-cover shadow-sm" style="width: 150px; height: 100px; border: 1px solid #eee;">
                                    <?php else: ?>
                                        <div class="bg-light rounded-3 d-flex justify-content-center align-items-center shadow-sm" style="width: 150px; height: 100px; border: 1px dashed #ccc;">
                                            <span class="text-muted small">Tanpa Gambar</span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 fw-semibold text-break"><?php echo e($sketch->title); ?></td>
                                <td class="py-3"><?php echo e($sketch->author); ?></td>
                                <td class="py-3">
                                    
                                    <?php
                                        $statusClass = $sketch->status == 'Published' ? 'badge-status-published' : 'badge-status-draft';
                                    ?>
                                    <span class="badge <?php echo e($statusClass); ?>"><?php echo e($sketch->status); ?></span>
                                </td>
                                <td class="py-3">
                                    <div class="d-flex gap-2">
                                        
                                        <a href="<?php echo e(route('admin.sketches.show', $sketch->slug)); ?>" class="btn btn-sm btn-outline-info rounded-pill px-3" style="border-color: #00617a; color: #00617a;" title="Lihat Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.sketches.edit', $sketch->slug)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3" style="border-color: #f4b704; color: #f4b704;" title="Edit Sketsa">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.sketches.destroy', $sketch->slug)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" onclick="confirmDelete(event, this.parentElement)" class="btn btn-sm btn-outline-danger rounded-pill px-3" style="border-color: #cb2786; color: #cb2786;" title="Hapus Sketsa">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">
                                    <i class="fas fa-box-open me-2"></i>Tidak ada sketsa yang ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($sketches->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(event, form) {
        event.preventDefault();

        Swal.fire({
            title: "Yakin ingin menghapus sketsa ini?",
            text: "Anda tidak akan bisa mengembalikannya!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#cb2786",
            cancelButtonColor: "#808080",
            confirmButtonText: "Ya, Hapus Sekarang!",
            cancelButtonText: "Batalkan",
            customClass: {
                popup: 'rounded-4',
                confirmButton: 'rounded-pill px-4',
                cancelButton: 'rounded-pill px-4'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Internshipractice\indiegologi_laravel\resources\views/sketches/index.blade.php ENDPATH**/ ?>